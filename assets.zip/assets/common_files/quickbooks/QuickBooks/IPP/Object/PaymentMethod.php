<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_PaymentMethod extends QuickBooks_IPP_Object
{
	
}
