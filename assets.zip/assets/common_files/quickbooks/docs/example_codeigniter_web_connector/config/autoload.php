<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$autoload['libraries'] = array('database');

$autoload['helper'] = array();

$autoload['plugin'] = array();

$autoload['config'] = array();

$autoload['language'] = array();

$autoload['model'] = array();
